package com.example.server.DAO;

public class DatabaseException extends Throwable {
    public DatabaseException(String s) {
        super(s);
    }
}
